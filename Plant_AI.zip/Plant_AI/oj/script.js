/* =============================================
   JAVASCRIPT - PLANT AI APPLICATION
   ============================================= */

// =============================================
// PWA Service Worker Registration
// =============================================

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Service worker registration deferred for future implementation
        console.log('PWA ready - Service worker support available');
    });
}

// =============================================
// DOM Elements
// =============================================

const navLinks = document.querySelectorAll('.nav-links a, .mobile-link');
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
const themeToggle = document.getElementById('themeToggle');
const dragDropZone = document.getElementById('dragDropZone');
const fileInput = document.getElementById('fileInput');
const uploadBtn = document.getElementById('uploadBtn');
const cameraBtn = document.getElementById('cameraBtn');
const predictBtn = document.getElementById('predictBtn');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const chatInput = document.getElementById('chatInput');
const chatMessages = document.getElementById('chatMessages');
const tabButtons = document.querySelectorAll('.tab-btn');

// =============================================
// Page Navigation
// =============================================

function navigateTo(pageName) {
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));

    // Show selected page
    const selectedPage = document.getElementById(pageName);
    if (selectedPage) {
        selectedPage.classList.add('active');
        window.scrollTo(0, 0);
        
        // Close mobile menu
        mobileMenu.classList.remove('active');
        hamburger.classList.remove('active');
    }
}

// Navigation Link Handlers
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const pageName = link.getAttribute('data-page');
        navigateTo(pageName);
    });
});

// =============================================
// Hamburger Menu
// =============================================

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    mobileMenu.classList.toggle('active');
});

// Close mobile menu when a link is clicked
document.querySelectorAll('.mobile-link').forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        mobileMenu.classList.remove('active');
    });
});

// =============================================
// Dark Mode Toggle
// =============================================

// Check for saved theme preference or default to light mode
const currentTheme = localStorage.getItem('theme') || 'light';
if (currentTheme === 'dark') {
    document.body.classList.add('dark-mode');
    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    
    if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        localStorage.setItem('theme', 'light');
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }
});

// =============================================
// Image Upload Functionality
// =============================================

// Drag and drop functionality
dragDropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dragDropZone.classList.add('dragover');
});

dragDropZone.addEventListener('dragleave', () => {
    dragDropZone.classList.remove('dragover');
});

dragDropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDropZone.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleImageUpload(files[0]);
    }
});

// Click to upload
dragDropZone.addEventListener('click', () => {
    fileInput.click();
});

uploadBtn.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
        handleImageUpload(e.target.files[0]);
    }
});

// Camera button
cameraBtn.addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment';
    input.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleImageUpload(e.target.files[0]);
        }
    });
    input.click();
});

function handleImageUpload(file) {
    if (!file.type.startsWith('image/')) {
        alert('Please upload an image file');
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        imagePreview.style.display = 'block';
        predictBtn.style.display = 'block';
        dragDropZone.style.display = 'none';
        uploadBtn.parentElement.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

function clearImage() {
    fileInput.value = '';
    imagePreview.style.display = 'none';
    predictBtn.style.display = 'none';
    dragDropZone.style.display = 'block';
    uploadBtn.parentElement.style.display = 'flex';
    
    // Hide results
    document.getElementById('resultsContainer').style.display = 'none';
    document.getElementById('emptyState').style.display = 'block';
    document.getElementById('loadingSpinner').style.display = 'none';
}

// =============================================
// Disease Detection
// =============================================

// Mock disease data (In real app, this would come from API)
const diseaseDatabase = {
    'Powdery Mildew': {
        confidence: 94,
        symptoms: [
            'White powdery coating on leaves and stems',
            'Leaves may curl or become distorted',
            'Reduced plant vigor and growth',
            'Flowers and buds may be affected'
        ],
        causes: [
            'Fungal infection',
            'Humid conditions with warm days',
            'Poor air circulation',
            'High nitrogen fertilization'
        ],
        treatment: [
            'Apply sulfur-based fungicides',
            'Use neem oil spray',
            'Apply potassium bicarbonate',
            'Remove heavily infected leaves',
            'Improve air circulation around plants',
            'Reduce nitrogen fertilizer application'
        ],
        prevention: [
            'Choose resistant plant varieties',
            'Maintain proper plant spacing',
            'Water at soil level, not foliage',
            'Prune to improve air circulation',
            'Avoid high-nitrogen fertilizers',
            'Clean up fallen leaves and debris'
        ]
    },
    'Early Blight': {
        confidence: 92,
        symptoms: [
            'Circular brown spots with concentric rings on lower leaves',
            'Spots progress upward on the plant',
            'Yellow halo around lesions',
            'Leaf yellowing and defoliation'
        ],
        causes: [
            'Fungal pathogen (Alternaria)',
            'Wet foliage conditions',
            'Overhead watering',
            'High humidity and warm temperatures',
            'Poor plant spacing'
        ],
        treatment: [
            'Remove infected leaves promptly',
            'Apply copper-based fungicides',
            'Use sulfur sprays',
            'Improve plant spacing and air circulation',
            'Water at soil level only',
            'Mulch around plants to prevent spores'
        ],
        prevention: [
            'Water plants in early morning',
            'Maintain proper spacing',
            'Use drip irrigation instead of overhead',
            'Remove lower leaves when plants are wet',
            'Rotate crops annually',
            'Clean garden tools between uses'
        ]
    },
    'Leaf Spot': {
        confidence: 88,
        symptoms: [
            'Small round to irregular spots on leaves',
            'Spots may have different colored rings',
            'Spots enlarge over time',
            'May develop yellow halo'
        ],
        causes: [
            'Various fungal and bacterial pathogens',
            'Wet leaf conditions',
            'Poor drainage',
            'Crowded plants',
            'Overhead irrigation'
        ],
        treatment: [
            'Remove infected leaves',
            'Apply fungicide sprays',
            'Increase air circulation',
            'Avoid wetting foliage',
            'Remove fallen debris',
            'Apply neem oil'
        ],
        prevention: [
            'Space plants properly',
            'Use drip irrigation',
            'Clean up fallen leaves',
            'Avoid working in wet garden',
            'Sanitize tools',
            'Choose resistant varieties'
        ]
    },
    'Rust': {
        confidence: 90,
        symptoms: [
            'Rust-colored or orange spots on leaf undersides',
            'Yellow spots on upper leaf surface',
            'Powdery texture on affected areas',
            'Severe infections cause leaf yellowing'
        ],
        causes: [
            'Fungal infection',
            'High humidity and wet conditions',
            'Cool nights and warm days',
            'Poor air circulation'
        ],
        treatment: [
            'Remove infected leaves',
            'Apply sulfur fungicide',
            'Use copper-based fungicide',
            'Improve air circulation',
            'Avoid overhead watering',
            'Remove rust spores with water spray'
        ],
        prevention: [
            'Ensure good plant spacing',
            'Water at soil level',
            'Remove infected leaves promptly',
            'Choose resistant varieties',
            'Mulch around plants',
            'Clean tools regularly'
        ]
    }
};

function predictDisease() {
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsContainer = document.getElementById('resultsContainer');
    const emptyState = document.getElementById('emptyState');

    // Show loading
    loadingSpinner.style.display = 'block';
    resultsContainer.style.display = 'none';
    emptyState.style.display = 'none';

    // Simulate API call
    setTimeout(() => {
        loadingSpinner.style.display = 'none';
        resultsContainer.style.display = 'block';

        // Pick a random disease from database
        const diseases = Object.keys(diseaseDatabase);
        const randomDisease = diseases[Math.floor(Math.random() * diseases.length)];
        const diseaseData = diseaseDatabase[randomDisease];

        // Display results
        displayDiseaseResults(randomDisease, diseaseData);
    }, 2000);
}

function displayDiseaseResults(diseaseName, diseaseData) {
    // Update disease name and confidence
    document.getElementById('diseaseName').textContent = diseaseName;
    document.getElementById('confidenceScore').textContent = diseaseData.confidence + '%';

    // Update tab contents
    const symptomsList = document.getElementById('symptomsList');
    symptomsList.innerHTML = diseaseData.symptoms.map(s => `<li>${s}</li>`).join('');

    const causesList = document.getElementById('causesList');
    causesList.innerHTML = diseaseData.causes.map(c => `<li>${c}</li>`).join('');

    const treatmentList = document.getElementById('treatmentList');
    treatmentList.innerHTML = diseaseData.treatment.map(t => `<li>${t}</li>`).join('');

    const preventionList = document.getElementById('preventionList');
    preventionList.innerHTML = diseaseData.prevention.map(p => `<li>${p}</li>`).join('');

    // Reset to symptoms tab
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
    });
    document.getElementById('symptoms').classList.add('active');

    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector('.tab-btn').classList.add('active');
}

// Tab switching
tabButtons.forEach(button => {
    button.addEventListener('click', () => {
        const tabName = button.getAttribute('data-tab');

        // Update active button
        tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // Update active pane
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        document.getElementById(tabName).classList.add('active');
    });
});

// =============================================
// Chatbot Functionality
// =============================================

const botResponses = {
    'powdery mildew|mildew': {
        response: 'Powdery mildew is a fungal disease causing white powder on leaves. Treatment includes: 1) Spray with sulfur-based fungicides, 2) Apply neem oil weekly, 3) Improve air circulation, 4) Water at soil level. Prevention: Choose resistant varieties and maintain spacing. Would you like specific pesticide recommendations?'
    },
    'organic pesticide|organic spray|natural pesticide': {
        response: 'Popular organic pesticides include: 1) Neem oil - effective against many insects, 2) Sulfur - treats fungal diseases, 3) Potassium bicarbonate - powdery mildew treatment, 4) Insecticidal soap - soft-bodied insects, 5) Copper spray - fungal diseases, 6) Bacillus thuringiensis - caterpillars. Always follow dosage instructions on the label.'
    },
    'prevention|prevent disease|disease prevention': {
        response: 'Best disease prevention practices: 1) Choose disease-resistant varieties, 2) Maintain proper plant spacing for air circulation, 3) Water at soil level only, 4) Rotate crops annually, 5) Remove infected leaves promptly, 6) Keep garden clean and debris-free, 7) Sterilize tools between uses, 8) Monitor plants regularly. Early detection is key!'
    },
    'watering|water|irrigation': {
        response: 'Proper watering reduces disease: 1) Use drip irrigation when possible, 2) Water in early morning to allow foliage to dry, 3) Avoid overhead watering, 4) Water at soil level, 5) Maintain consistent moisture - not too wet or dry, 6) Reduce watering in humid conditions, 7) Mulch to regulate soil moisture. Most diseases spread in wet conditions.'
    },
    'fertilizer|nutrients|nitrogen': {
        response: 'Balanced nutrition supports plant health: 1) Use balanced fertilizer (equal N-P-K), 2) Avoid excessive nitrogen which promotes soft growth, 3) Add organic compost for sustained nutrition, 4) Use slow-release fertilizers, 5) Monitor soil pH, 6) Consider micronutrients like calcium and magnesium. Healthy plants resist diseases better!'
    },
    'crop rotation|rotation': {
        response: 'Crop rotation breaks disease cycles: 1) Rotate plant families yearly, 2) Avoid planting same crop in same spot, 3) Different family plants use different nutrients, 4) Reduces soil-borne pathogens, 5) Plan 3-4 year rotation cycles, 6) Include cover crops and legumes. This is essential for sustainable agriculture.'
    },
    'hello|hi|hey': {
        response: 'Hello! 👋 I\'m PlantAI Assistant. I can help you with disease identification, treatment recommendations, prevention strategies, and general farming advice. What would you like to know about plant health?'
    },
    'default': {
        response: 'I\'m here to help with plant disease management! You can ask me about: disease treatments, organic pesticides, prevention tips, watering practices, crop rotation, fertilization, and general farming advice. What would you like to know?'
    }
};

function findBotResponse(message) {
    const lowerMessage = message.toLowerCase();
    
    for (let [keywords, data] of Object.entries(botResponses)) {
        const keywordArray = keywords.split('|');
        for (let keyword of keywordArray) {
            if (lowerMessage.includes(keyword)) {
                return data.response;
            }
        }
    }
    
    return botResponses['default'].response;
}

function sendMessage(element) {
    // If called from suggestion button
    if (element.textContent) {
        chatInput.value = element.textContent;
    }
    sendChatMessage();
}

function sendChatMessage() {
    const message = chatInput.value.trim();
    
    if (message === '') return;

    // Add user message
    addMessage(message, 'user');
    chatInput.value = '';

    // Simulate bot response delay
    setTimeout(() => {
        const botResponse = findBotResponse(message);
        addMessage(botResponse, 'bot');
    }, 500);
}

function addMessage(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = `<p>${message}</p>`;

    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);

    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // Hide suggestions after first interaction
    const suggestedQuestions = document.getElementById('suggestedQuestions');
    if (suggestedQuestions && suggestedQuestions.style.display !== 'none') {
        suggestedQuestions.style.display = 'none';
    }
}

// Send message with Enter key
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendChatMessage();
    }
});

// =============================================
// Smooth Scrolling
// =============================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// =============================================
// Demo Button Handler
// =============================================

document.querySelectorAll('button:has(i.fa-play)').forEach(btn => {
    btn.addEventListener('click', () => {
        // Create sample image data
        const canvas = document.createElement('canvas');
        canvas.width = 224;
        canvas.height = 224;
        const ctx = canvas.getContext('2d');
        
        // Draw gradient background
        const gradient = ctx.createLinearGradient(0, 0, 224, 224);
        gradient.addColorStop(0, '#2ecc71');
        gradient.addColorStop(1, '#27ae60');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 224, 224);
        
        // Draw leaf shape
        ctx.fillStyle = 'rgba(0, 100, 0, 0.3)';
        ctx.beginPath();
        ctx.ellipse(112, 112, 60, 80, Math.PI / 6, 0, Math.PI * 2);
        ctx.fill();
        
        // Convert to image
        previewImg.src = canvas.toDataURL();
        imagePreview.style.display = 'block';
        predictBtn.style.display = 'block';
        dragDropZone.style.display = 'none';
        uploadBtn.parentElement.style.display = 'none';
        
        // Navigate to detection page
        navigateTo('detection');
    });
});

// =============================================
// Initialize
// =============================================

// Set home page as default
window.addEventListener('load', () => {
    navigateTo('home');
});

// Add animation to progress bars on page load
window.addEventListener('load', () => {
    const progressFills = document.querySelectorAll('.progress-fill');
    progressFills.forEach(fill => {
        fill.style.width = fill.style.width;
    });
});

// Scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe cards for animation
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll(
        '.feature-card, .objective-card, .app-card, .tech-card, .step-card'
    );
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
        observer.observe(card);
    });
});
