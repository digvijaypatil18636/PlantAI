# API Configuration and Integration Guide

## Backend API Setup

### Environment Configuration
```
API_BASE_URL=http://localhost:5000
API_TIMEOUT=30000
ENABLE_CORS=true
```

### API Endpoints

#### 1. Disease Prediction
```
POST /api/predict
Content-Type: multipart/form-data

Request:
{
  "image": <binary image file>
}

Response:
{
  "success": true,
  "disease": "Powdery Mildew",
  "confidence": 0.94,
  "symptoms": [
    "White powdery coating on leaves and stems",
    "Leaves may curl or become distorted",
    "Reduced plant vigor and growth"
  ],
  "causes": [
    "Fungal infection",
    "Humid conditions with warm days",
    "Poor air circulation"
  ],
  "treatment": [
    "Apply sulfur-based fungicides",
    "Use neem oil spray",
    "Apply potassium bicarbonate"
  ],
  "prevention": [
    "Choose resistant plant varieties",
    "Maintain proper plant spacing",
    "Water at soil level, not foliage"
  ],
  "processing_time_ms": 450
}
```

#### 2. Chatbot Response
```
POST /api/chat
Content-Type: application/json

Request:
{
  "message": "How do I treat powdery mildew?",
  "conversation_id": "optional-user-id"
}

Response:
{
  "success": true,
  "response": "Powdery mildew treatment includes...",
  "suggested_follow_ups": [
    "What are organic alternatives?",
    "How do I prevent it?",
    "Which pesticides are safe?"
  ]
}
```

#### 3. Disease List
```
GET /api/diseases

Response:
{
  "success": true,
  "diseases": [
    {
      "id": 1,
      "name": "Powdery Mildew",
      "scientific_name": "Erysiphe cichoracearum",
      "host_plants": ["Squash", "Cucumber", "Pumpkin"],
      "severity": "medium"
    },
    ...
  ]
}
```

#### 4. History
```
GET /api/history?limit=10
Authorization: Bearer <user-token>

Response:
{
  "success": true,
  "predictions": [
    {
      "id": "pred-123",
      "timestamp": "2024-02-07T10:30:00Z",
      "disease": "Powdery Mildew",
      "confidence": 0.94,
      "image_url": "https://..."
    }
  ]
}
```

## Frontend Integration

### Update script.js for API Integration
```javascript
// Configuration
const API_CONFIG = {
  BASE_URL: process.env.REACT_APP_API_URL || 'http://localhost:5000',
  TIMEOUT: 30000,
  PREDICT_ENDPOINT: '/api/predict',
  CHAT_ENDPOINT: '/api/chat',
};

// Prediction API Call
async function predictDiseaseAPI(imageFile) {
  const formData = new FormData();
  formData.append('image', imageFile);

  try {
    const response = await fetch(
      `${API_CONFIG.BASE_URL}${API_CONFIG.PREDICT_ENDPOINT}`,
      {
        method: 'POST',
        body: formData,
        timeout: API_CONFIG.TIMEOUT,
      }
    );

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Prediction error:', error);
    throw error;
  }
}

// Chat API Call
async function sendChatMessageAPI(message) {
  try {
    const response = await fetch(
      `${API_CONFIG.BASE_URL}${API_CONFIG.CHAT_ENDPOINT}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: message,
          conversation_id: localStorage.getItem('conversation_id'),
        }),
        timeout: API_CONFIG.TIMEOUT,
      }
    );

    if (!response.ok) {
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Chat error:', error);
    throw error;
  }
}
```

## Flask Backend Example

### Installation
```bash
pip install flask flask-cors python-dotenv tensorflow opencv-python pillow numpy
```

### Main Application
```python
# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from tensorflow import keras
from PIL import Image
import cv2
import numpy as np
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# Load pre-trained model
MODEL_PATH = 'models/plant_disease_model.h5'
model = keras.models.load_model(MODEL_PATH)

# Class labels
CLASS_LABELS = [
    'Powdery Mildew',
    'Early Blight',
    'Leaf Spot',
    'Rust',
    'Healthy'
]

# Disease database
DISEASE_INFO = {
    'Powdery Mildew': {
        'symptoms': [
            'White powdery coating on leaves',
            'Distorted leaf growth',
            'Reduced plant vigor'
        ],
        'causes': ['Fungal infection', 'High humidity', 'Poor air circulation'],
        'treatment': ['Sulfur spray', 'Neem oil', 'Potassium bicarbonate'],
        'prevention': ['Plant spacing', 'Resistant varieties', 'Proper watering']
    },
    # ... add more diseases
}

@app.route('/api/predict', methods=['POST'])
def predict_disease():
    try:
        # Validate request
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
        
        file = request.files['image']
        if file.filename == '':
            return jsonify({'error': 'No image selected'}), 400
        
        # Read and process image
        img_array = np.fromfile(file, np.uint8)
        img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (224, 224))
        img = img.astype('float32') / 255.0
        img = np.expand_dims(img, axis=0)
        
        # Make prediction
        prediction = model.predict(img)
        confidence = float(np.max(prediction))
        disease_idx = np.argmax(prediction)
        disease_name = CLASS_LABELS[disease_idx]
        
        # Get disease information
        disease_data = DISEASE_INFO.get(disease_name, {})
        
        return jsonify({
            'success': True,
            'disease': disease_name,
            'confidence': round(confidence * 100, 2),
            'symptoms': disease_data.get('symptoms', []),
            'causes': disease_data.get('causes', []),
            'treatment': disease_data.get('treatment', []),
            'prevention': disease_data.get('prevention', [])
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        message = data.get('message', '').lower()
        
        # Simple keyword matching (replace with NLP for production)
        if any(word in message for word in ['mildew', 'powdery']):
            response = 'For powdery mildew, I recommend: 1) Sulfur spray, 2) Neem oil, 3) Good air circulation. Would you like more details?'
        elif any(word in message for word in ['prevention', 'prevent']):
            response = 'Prevention tips: proper spacing, resistant varieties, correct watering, regular monitoring. What specific crop?'
        elif any(word in message for word in ['pesticide', 'chemical']):
            response = 'Popular safe options: neem oil (organic), sulfur (fungal), insecticidal soap (insects). Always follow label instructions.'
        else:
            response = 'I can help with disease treatment, prevention, pesticides, and farming tips. What would you like to know?'
        
        return jsonify({
            'success': True,
            'response': response,
            'suggested_follow_ups': [
                'Tell me more about treatment',
                'How do I prevent this?',
                'What pesticides are safe?'
            ]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/diseases', methods=['GET'])
def get_diseases():
    diseases = [
        {
            'id': i,
            'name': label,
            'info': DISEASE_INFO.get(label, {})
        }
        for i, label in enumerate(CLASS_LABELS)
    ]
    return jsonify({'success': True, 'diseases': diseases})

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'healthy', 'model': 'loaded'})

if __name__ == '__main__':
    app.run(
        debug=os.getenv('FLASK_DEBUG', True),
        host=os.getenv('FLASK_HOST', '0.0.0.0'),
        port=int(os.getenv('FLASK_PORT', 5000))
    )
```

### Requirements.txt
```
Flask==2.3.2
Flask-CORS==4.0.0
TensorFlow==2.13.0
Keras==2.13.0
opencv-python==4.8.0.76
Pillow==10.0.0
numpy==1.24.3
python-dotenv==1.0.0
gunicorn==21.2.0
```

### Environment Variables (.env)
```
FLASK_ENV=development
FLASK_DEBUG=True
FLASK_HOST=0.0.0.0
FLASK_PORT=5000
CORS_ORIGINS=http://localhost:3000,http://localhost:8000
MODEL_PATH=models/plant_disease_model.h5
```

## Deployment

### Docker Setup
```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

ENV FLASK_APP=app.py
ENV FLASK_ENV=production

EXPOSE 5000

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "app:app"]
```

### Docker Compose
```yaml
version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      FLASK_ENV: production
      DATABASE_URL: sqlite:///app.db
    volumes:
      - ./backend:/app

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    depends_on:
      - backend
```

## Testing

### Unit Tests
```python
import unittest
from app import app

class TestAPI(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
    
    def test_health(self):
        response = self.app.get('/health')
        self.assertEqual(response.status_code, 200)
    
    def test_predict_no_image(self):
        response = self.app.post('/api/predict')
        self.assertEqual(response.status_code, 400)

if __name__ == '__main__':
    unittest.main()
```

## Performance Optimization

- Use image compression before upload
- Implement request rate limiting
- Cache disease information
- Use model quantization for faster inference
- Implement batch prediction for multiple images
- Use Redis for caching chat responses

## Security Considerations

- Validate all inputs
- Implement HTTPS only
- Use API keys for authentication
- Implement CORS properly
- Sanitize file uploads
- Rate limit API endpoints
- Use environment variables for secrets

---

For detailed implementation, refer to Flask documentation and TensorFlow model deployment guides.
